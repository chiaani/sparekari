## [Alpha 1.0] - 2021-05-18
### Blockchain initialized

- This is the first release of the Spare coin! Blockchain consensus, proof of time, and proof of space are included.