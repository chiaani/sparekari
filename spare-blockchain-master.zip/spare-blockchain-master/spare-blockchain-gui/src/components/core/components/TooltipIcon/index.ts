export { default } from './TooltipIcon';
