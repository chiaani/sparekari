export { default } from './Link';
