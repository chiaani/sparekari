export { default } from './CopyToClipboard';
