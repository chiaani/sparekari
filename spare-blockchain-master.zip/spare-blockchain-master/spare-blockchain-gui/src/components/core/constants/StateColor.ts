enum StateColor {
  SUCCESS = '#00D983',
  WARNING = '#F7CA3E',
  ERROR = '#E9398D',
}

export default StateColor;
