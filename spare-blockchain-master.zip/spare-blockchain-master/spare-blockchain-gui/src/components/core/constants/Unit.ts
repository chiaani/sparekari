enum Unit {
  SPARE = 'SPARE',
  MOJO = 'MOJO',
  COLOURED_COIN = 'COLOUREDCOIN',
}

export default Unit;
