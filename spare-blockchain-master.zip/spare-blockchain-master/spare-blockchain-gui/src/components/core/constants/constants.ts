export const IS_MAINNET = process.env.REACT_APP_TESTNET !== 'true'; // eslint-disable-line
