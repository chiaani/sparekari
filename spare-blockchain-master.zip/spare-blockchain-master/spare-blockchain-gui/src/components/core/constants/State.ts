enum State {
  SUCCESS,
  WARNING,
  ERROR,
}

export default State;