enum FullNodeState {
  SYNCHING = 'SYNCHING',
  ERROR = 'ERROR',
  SYNCED = 'SYNCED',
}

export default FullNodeState;
