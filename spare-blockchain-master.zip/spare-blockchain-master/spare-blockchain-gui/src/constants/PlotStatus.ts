enum PlotStatus {
  SUBMITTED = 'SUBMITTED',
  RUNNING = 'RUNNING',
  REMOVING = 'REMOVING',
  FINISHED = 'FINISHED',
}

export default PlotStatus;
