export default {
  local_test: process.env.LOCAL_TEST === 'true',
  backup_host: 'https://backup.sparecoin.org',
};
