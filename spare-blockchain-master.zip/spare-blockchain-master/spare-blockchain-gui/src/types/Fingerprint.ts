type Fingerprint = number;

export default Fingerprint;
