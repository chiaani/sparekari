type ProofsOfSpace = {
  [key: string]: [string, ProofsOfSpace][];
};

export default ProofsOfSpace;
