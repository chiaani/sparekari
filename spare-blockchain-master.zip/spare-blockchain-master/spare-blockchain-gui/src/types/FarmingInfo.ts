type FarmingInfo = {
  challenge_hash: string;
  signage_point: string;
  timestamp: number;
  passed_filter: number;
  proofs: number;
  total_plots: number;
};

export default FarmingInfo;
