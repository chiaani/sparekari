type G2Element = string;

export default G2Element;
