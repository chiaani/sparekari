type FoliageTransactionBlock = {
  additions_root: string;
  filter_hash: string;
  height: number;
  prev_block_hash: string;
  removals_root: string;
  timestamp: string;
  transactions_info_hash: string;
};

export default FoliageTransactionBlock;
