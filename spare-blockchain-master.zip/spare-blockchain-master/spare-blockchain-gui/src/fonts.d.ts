declare module '*.woff';
declare module '*.woff2';
declare module '*.ttf';
