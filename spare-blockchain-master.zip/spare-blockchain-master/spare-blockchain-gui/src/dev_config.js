const dev_config = {
  redux_tool: null,
  react_tool: null
  //react_tool: "/Library/Application Support/Google/Chrome/Default/Extensions/fmkadmapgofadopljbjfkapdkoienihi/4.6.0_0",
  //redux_tool: "/Library/Application Support/Google/Chrome/Default/Extensions/lmhkpmbekcpmknklioeibfkpmmfibljd/2.17.0_0"
};

module.exports = dev_config;
