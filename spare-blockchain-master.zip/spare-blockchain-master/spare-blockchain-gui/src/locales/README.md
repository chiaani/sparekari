# Localization

Thanks for helping to translate the GUI for Spare Blockchain.

Please head over to our [Crowdin project](https://crowdin.com/project/spare-blockchain/) and add/edit translations there.
