import 'core-js/stable';
import 'regenerator-runtime/runtime';
import { polyfill } from 'es6-promise';
import 'isomorphic-fetch';

polyfill();
