window.remote = require('electron').remote;
window.ipcRenderer = require('electron').ipcRenderer;
window.shell = require('electron').shell;
